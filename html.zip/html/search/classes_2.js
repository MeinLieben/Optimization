var searchData=
[
  ['optimizing',['Optimizing',['../class_optimizing.html',1,'']]]
];
