var searchData=
[
  ['stop',['stop',['../classstop_criterion.html#a2dfb6e71135964705a261035ee6b6f4b',1,'stopCriterion::stop()'],['../classstop_grad.html#ac0e4a9f65dcfeb62cec9378224facb61',1,'stopGrad::stop()'],['../classstop_diff_elem.html#aef65075f6546d7af81b09304f8ee4175',1,'stopDiffElem::stop()'],['../classstop_rel_diff_fun.html#a44d0fb17b827e56c4dfb29cf634ed933',1,'stopRelDiffFun::stop()'],['../classstop_stochastic.html#a866b4501cdf7cbef9436bc94ae327ab6',1,'stopStochastic::stop()']]]
];
