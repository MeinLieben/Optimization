var searchData=
[
  ['stochasticoptimizing',['StochasticOptimizing',['../class_stochastic_optimizing.html',1,'']]],
  ['stopcriterion',['stopCriterion',['../classstop_criterion.html',1,'']]],
  ['stopdiffelem',['stopDiffElem',['../classstop_diff_elem.html',1,'']]],
  ['stopgrad',['stopGrad',['../classstop_grad.html',1,'']]],
  ['stopreldifffun',['stopRelDiffFun',['../classstop_rel_diff_fun.html',1,'']]],
  ['stopstochastic',['stopStochastic',['../classstop_stochastic.html',1,'']]]
];
