var searchData=
[
  ['state',['State',['../classstop_criterion.html#a4e874e2a7dd1a145253d2e1052095528',1,'stopCriterion']]]
];
