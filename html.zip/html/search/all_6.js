var searchData=
[
  ['reldifffun',['relDiffFun',['../classstop_criterion.html#a4e874e2a7dd1a145253d2e1052095528a87433cde0d09466385c724883fdf9c66',1,'stopCriterion']]]
];
