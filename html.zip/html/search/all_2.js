var searchData=
[
  ['geta',['geta',['../class_area.html#a9aa1c1660f894516f8583a4e1398e5c7',1,'Area']]],
  ['getb',['getb',['../class_area.html#ab1b7a11f2f263e9c1e1ff990f065e0ae',1,'Area']]],
  ['grad',['grad',['../classstop_criterion.html#a4e874e2a7dd1a145253d2e1052095528ae37b6e74a3bd476dfde7e0577b9e81d6',1,'stopCriterion']]],
  ['gradientoptimizing',['GradientOptimizing',['../class_gradient_optimizing.html',1,'']]],
  ['groptimizing',['GROptimizing',['../class_g_r_optimizing.html',1,'']]]
];
