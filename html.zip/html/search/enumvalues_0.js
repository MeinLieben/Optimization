var searchData=
[
  ['diffelem',['diffElem',['../classstop_criterion.html#a4e874e2a7dd1a145253d2e1052095528a3bf11ba8f15c0c80c0b89eeca0db1c0e',1,'stopCriterion']]]
];
