var searchData=
[
  ['gradientoptimizing',['GradientOptimizing',['../class_gradient_optimizing.html',1,'']]],
  ['groptimizing',['GROptimizing',['../class_g_r_optimizing.html',1,'']]]
];
