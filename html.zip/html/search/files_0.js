var searchData=
[
  ['optimizing_2eh',['optimizing.h',['../optimizing_8h.html',1,'']]]
];
