var searchData=
[
  ['disttoborder',['distToBorder',['../class_area.html#a5aa1ae27325ec2585e5c60d29f0f7a67',1,'Area']]]
];
