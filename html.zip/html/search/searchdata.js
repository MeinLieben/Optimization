var indexSectionsWithContent =
{
  0: "adginors",
  1: "agos",
  2: "o",
  3: "dginos",
  4: "s",
  5: "dgr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator"
};

