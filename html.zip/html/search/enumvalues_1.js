var searchData=
[
  ['grad',['grad',['../classstop_criterion.html#a4e874e2a7dd1a145253d2e1052095528ae37b6e74a3bd476dfde7e0577b9e81d6',1,'stopCriterion']]]
];
