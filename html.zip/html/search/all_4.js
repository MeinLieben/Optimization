var searchData=
[
  ['nstop',['nStop',['../classstop_criterion.html#ac7f47dc92a570ab9be642a650d4b9937',1,'stopCriterion']]]
];
